﻿# Sample page

Welcome to **MdXaml**

## Is this markdown render really? Can it render table?

| columnA | columnB |
| ------- | ------- |
| foo     | bar     |